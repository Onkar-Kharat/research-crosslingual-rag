| System_or_Ablation | Correct_Count | Accuracy | Observed_2cl_Macro_F1 | Standard_3cl_Macro_F1 | Coverage_Pct | Mean_E2E_Latency_ms | Median_E2E_Latency_ms |
| --- | --- | --- | --- | --- | --- | --- | --- |
| No-Check (Translated Evidence Only) | 52 | 0.31901840490797545 | 0.34084145021645024 | 0.2272276334776335 | 0.0 | 2939.1 | 2869.0 |
| Direct Multilingual (Original Hindi Only) | 61 | 0.37423312883435583 | 0.3800268696820421 | 0.2533512464546947 | 100.0 | 4802.8 | 4703.4 |
| Always-Check (Dual Consensus via 0.5 Avg) | 51 | 0.3128834355828221 | 0.3205009276437848 | 0.21366728509585653 | 100.0 | 7741.9 | 7620.1 |
| Selective-Check (Ours: Hard Routing, tau*=0.30) | 64 | 0.39263803680981596 | 0.4066844919786096 | 0.2711229946524064 | 83.4 | 6968.8 | 7441.5 |
| Ablation 1: Triggered Posterior Averaging (Paper Eq 1) | 50 | 0.3067484662576687 | 0.31655011655011656 | 0.21103341103341103 | 83.4 | 6968.8 | 7441.5 |
| Ablation 2: Uncertainty-Only Routing | 59 | 0.3619631901840491 | 0.3676393955184992 | 0.24509293034566615 | 83.4 | 6946.0 | 7430.0 |
| Ablation 3: Numeral-Mismatch-Only Routing | 65 | 0.3987730061349693 | 0.40792682926829266 | 0.2719512195121951 | 96.9 | 7631.7 | 7620.0 |
| Control: Random Routing (83.4% Coverage, 100 seeds) | 59 | 0.36398773006134966 | 0.3751890904757083 | 0.25012606031713885 | 83.4 | 6968.8 | 7441.5 |
| Oracle Upper Bound (Non-Deployable Ceiling) | 93 | 0.5705521472392638 | 0.5370813397129186 | 0.35805422647527907 | 100.0 | 7741.9 | 7620.1 |
