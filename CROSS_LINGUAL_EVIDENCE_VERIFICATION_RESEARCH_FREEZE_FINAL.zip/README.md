# Cross-Lingual Evidence Verification: Prediction Sensitivity and Routing Disagreement Under Hindi-to-English Translation Shift

**Certified Research Status:** `FROZEN — EXPLORATORY COMPUTATIONAL STUDY`  
**Protocol Version:** `v1.0-observational`  
**Deliverable Archive:** `CROSS_LINGUAL_EVIDENCE_VERIFICATION_RESEARCH_FREEZE_FINAL.zip`  

---

## 1. Research Overview & Fixed Scope

This repository contains the complete experimental code, canonical predictions, evaluation metrics, literature audits, and blinded human annotation system for a controlled observational study investigating how Hindi-to-English machine translation affects multilingual NLI evidence verification.

### Locked Scientific Scope:
- **Study Scope:** An observational study of model prediction sensitivity and routing behavior when evidence snippets are presented in original Hindi versus machine-translated English.
- **Model Evaluated:** Multilingual NLI verifier (`mDeBERTa-v3-base-xnli-multilingual-nli-2mil7`, 86M params) paired with MarianMT (`Helsinki-NLP/opus-mt-hi-en`).
- **Benchmark Dataset:** X-Fact multilingual fact-checking benchmark (`hi` partition; $N_{\text{dev}}=103$, $N_{\text{test}}=163$).
- **Explicit Boundaries:**
  - *No End-to-End RAG:* Evaluates pre-retrieved evidence snippets paired with claims; does not evaluate retrieval or text generation.
  - *No Causal Translation Claims:* Without authentic bilingual human annotations confirming semantic distortions, prediction flips reflect model sensitivity and cross-lingual disagreement, not proven translation-caused errors.
  - *Exploratory Test Split:* The 163-item test split was inspected in earlier iterations and is treated as an exploratory descriptive benchmark.

---

## 2. Canonical Research Results Summary ($N=163$ Test)

All values are deterministically derived from canonical per-instance model predictions (`canonical_results.csv`):

### 2.1 Primary Descriptive Sensitivity Metrics
- **Paired Prediction Agreement Rate:** **36.20%** (59 / 163) [95% Wilson CI: 29.22%, 43.81%]
- **Paired Prediction Disagreement Rate:** **63.80%** (104 / 163) [95% Wilson CI: 56.19%, 70.78%]
- **Translated $\text{SUP} \to$ Original $\text{CON}$ Flip Rate:** **48.44%** (31 / 64) [95% Wilson CI: 36.63%, 60.42%]
- **Translated $\text{CON} \to$ Original $\text{SUP}$ Flip Rate:** **40.91%** (18 / 44) [95% Wilson CI: 27.69%, 55.59%]
- **Translated $\text{NEU} \to$ Original $\text{CON}$ Flip Rate:** **41.82%** (23 / 55) [95% Wilson CI: 29.74%, 54.97%]

### 2.2 Secondary Benchmark Comparison
| System / Baseline | Observed Accuracy | 95% Wilson CI | Observed 2-Class F1 | Coverage | Latency (ms) | Paired McNemar Significance |
|---|---|---|---|---|---|---|
| **No-Check (Translated Only)** | **28.22%** (46/163) | [21.47%, 35.58%] | 0.3018 | 0.0% (0/163) | 3,650.4 ms | vs Direct Multi: $b=27, c=51$, $\chi^2=6.7821$, $p = 0.008772$ |
| **Selective-Check ($\tau^*=0.650$)** | **28.22%** (46/163) | [21.47%, 35.58%] | 0.2950 | 7.98% (13/163) | 4,613.8 ms | Reference ($b=4, c=4, p=1.0000$ vs No-Check) |
| **Direct Multilingual (Original Only)** | **42.94%** (70/163) | [35.57%, 50.92%] | 0.3700 | 100.0% (163/163) | 11,295.6 ms | vs Selective: $b=23, c=47$, $\chi^2=7.5571$, $p = 0.005583$ |
| **Always-Check (Dual Consensus)** | **36.81%** (60/163) | [29.45%, 44.17%] | 0.3657 | 100.0% (163/163) | 14,945.9 ms | vs Selective: $b=9, c=23$, $\chi^2=5.2812$, $p = 0.0201$ |
| **Majority Baseline (Always CON)** | **87.12%** (142/163) | [81.16%, 91.39%] | 0.4656 | — | 0.0 ms | Baseline ceiling |
| **Random Control (100 Seeds)** | **29.24%** (mean) | [26.38%, 31.90%] | 0.3082 | 7.98% (13/163) | 4,613.8 ms | vs Selective: $p = 0.2669$ |

### 2.3 Development Utility Optimality ($N=103$ Dev)
- **Dev No-Check Baseline Utility ($Coverage=0.0\%$):** $J = 0.2104$.
- **Dev Cascade Peak Utility ($\tau^* = 0.650, Coverage=12.62\%$):** $J = 0.2023$.
- **Empirical Takeaway:** Under the linear development objective $J = \text{MacroF1} - 0.20 \cdot \text{Coverage}$, the No-Check baseline outperforms the selective cascade ($\Delta J = -0.0081$). The selective cascade does not yield a Pareto improvement.

---

## 3. Repository Structure

```text
├── README.md                                    # This document
├── FREEZE_AUDIT.md                              # Comprehensive freeze audit report
├── FILE_INVENTORY.csv                           # Full 539-file inventory and verification statuses
├── ISSUES_AND_FIXES.csv                         # Defect ledger, root causes, fixes, and audit trails
├── FROZEN_PROTOCOL.md                           # Final frozen experimental protocol
├── EXPERIMENT_LINEAGE.md                        # End-to-end data traceability from raw splits to metrics
├── ANNOTATION_HANDOFF.md                        # External bilingual evaluator handoff guide
├── RELATED_WORK_AND_NOVELTY_AUDIT.md            # Literature review and comparison table
├── LIMITATIONS.md                               # Explicit boundaries and prohibited claims
├── FREEZE_MANIFEST.md                           # Formal freeze manifest and reproduction commands
├── canonical_results.csv                        # Machine-readable canonical results table
│
├── annotation_tool/                             # Real human annotation workflow
│   ├── app/index.html                           # Self-contained offline browser annotation app
│   ├── packets/                                 # Blinded evaluation packets (PACKET_A / PACKET_B handoffs)
│   ├── scripts/validate_submissions.py          # Non-destructive schema & rationale validator
│   └── scripts/analyze_agreement.py             # Multi-class Cohen's kappa and agreement analysis
│
├── data/splits/                                 # Deterministic dataset partitions
│   ├── hindi_dev.jsonl                          # Development partition (103 instances)
│   └── hindi_test.jsonl                         # Test partition (163 instances)
│
├── experiments/results_canonical/               # Canonical per-instance predictions and tables
│   ├── canonical_dev_predictions.csv            # Per-instance development predictions
│   ├── canonical_test_predictions.csv           # Per-instance test predictions
│   ├── canonical_benchmark_table.csv            # Canonical system comparison table
│   ├── canonical_statistical_tests.csv          # McNemar and permutation test results
│   └── canonical_dev_tuning.csv                 # Complete development threshold sweep
│
├── literature/                                  # Literature audit
│   └── LITERATURE_AUDIT.csv                     # 11 peer-reviewed primary citations audited
│
├── scripts/                                     # Reproducible experimental scripts
│   ├── run_corrected_experiments.py             # Model inference & threshold tuning
│   ├── compute_evaluation_metrics_corrected.py  # Canonical metric and statistical calculation
│   ├── generate_publication_figures.py          # Vector/raster figure generator
│   └── package_freeze_candidate_v6.py           # Freeze packaging and clean-room test script
│
└── tests/                                       # Automated regression test suite (42 tests)
    └── run_all_tests.py                         # Master test runner
```

---

## 4. Setup and Quick Reproduction

### 4.1 Prerequisites
- Python 3.10 to 3.14 (Verified on Python 3.14.7, 64-bit AMD64).
- Compatible with Windows 10/11, macOS, and Linux (Ubuntu 22.04+).

### 4.2 Installation
```bash
# Clone or extract repository
git clone https://github.com/Onkar-Kharat/research-crosslingual-rag.git
cd research-crosslingual-rag

# Create virtual environment
python -m venv .venv
# Activate on Windows (PowerShell):
.venv\Scripts\Activate.ps1
# Activate on Linux/macOS:
source .venv/bin/activate

# Install lightweight statistical and evaluation dependencies
pip install -r requirements.txt
```

### 4.3 Execute Automated Verification Suite
Run all 42 automated tests across 8 verification modules:
```bash
python tests/run_all_tests.py
```
*Expected runtime: $< 1.0$ second. All 42 tests must pass.*

### 4.4 Recompute Canonical Tables and Figures
```bash
# Recompute all metrics directly from per-instance predictions
python scripts/compute_evaluation_metrics_corrected.py

# Regenerate publication figures
python scripts/generate_publication_figures.py
```

### 4.5 Verify Annotation Tooling
```bash
# Validate sample QA submissions
python annotation_tool/scripts/validate_submissions.py \
  --file1 annotation_tool/tests/fixtures/valid_submission_A1.json \
  --file2 annotation_tool/tests/fixtures/valid_submission_A2.json
```

---

## 5. Checksum Verification

Verify file integrity against the master SHA-256 manifest:
```bash
# On Linux / macOS:
sha256sum -c FINAL_PASS/SHA256SUMS.txt

# On Windows (PowerShell):
Get-Content FINAL_PASS/SHA256SUMS.txt | ForEach-Object {
    $hash, $file = $_ -split '\s+', 2
    if ($file -and (Test-Path $file)) {
        $actual = (Get-FileHash -Algorithm SHA256 $file).Hash.ToLower()
        if ($actual -eq $hash.ToLower()) {
            Write-Host "OK: $file" -ForegroundColor Green
        } else {
            Write-Host "MISMATCH: $file" -ForegroundColor Red
        }
    }
}
```
