# FINAL ONE-PASS RESEARCH AUDIT, REPAIR, AND FREEZE PROMPT

## Mission
This is the final research-only pass for the project. Do not start a new cycle of superficial status-report edits. Independently verify the supplied V4 ZIP, make all changes that are scientifically valid and computationally possible, regenerate the canonical outputs where required, and deliver either:

1. a genuinely reproducible, honestly scoped frozen research ZIP; or
2. a final `NOT_FROZEN` package with a short, evidence-backed list of blockers that require real external action.

Do not rewrite or format the manuscript in this task. The user will review the research package before manuscript work begins.

## Files the user will provide
- `CROSS_LINGUAL_EVIDENCE_VERIFICATION_RESEARCH_V4_NOT_FROZEN.zip`
- `V4_PREMANUSCRIPT_READINESS_REVIEW.md`
- `ANTIGRAVITY_V4_FINAL_PREMANUSCRIPT_AUDIT_PROMPT.md`

Treat the V4 ZIP as the project to audit, and the two review files as hypotheses/checklists—not ground truth. Verify each finding against current code, data, logs, and outputs. Do not trust status text over executable evidence.

## Fixed scope decision to stop scope drift
For this one pass, adopt the narrow, computationally supportable research scope already described as Option C:

**“Cross-lingual verifier prediction sensitivity and routing disagreement under Hindi-to-English translation shift.”**

The evaluated system consumes existing claim/evidence instances, translates Hindi evidence into English where applicable, and applies an NLI verifier. It does not implement end-to-end retrieval plus generation. Do not call it an end-to-end RAG system.

The central claims must be observational, not causal:
- Allowed: original-language and translated-evidence predictions differ; one condition sometimes corrects or degrades predictions relative to the mapped dataset labels; the tested selective routing strategy does or does not improve the defined metrics.
- Not allowed without real, independently performed bilingual annotation: “translation distortion caused X errors,” “X% of errors are confirmed translation-fidelity errors,” or similar causal/semantic validation claims.
- Remove all fake, simulated, hard-coded, or invalidated human annotation data from active evidence and summaries. Preserve such files only under a clearly named quarantine/audit directory, never in active analysis paths.
- Mark human annotation as “not performed / future work”; it is not a required gate for this narrower observational scope. If the project keeps any causal claim, the project cannot freeze until genuine human annotation is completed and verified.

This is a computational research freeze, not a guarantee of TACL acceptance. State plainly whether the current evidence is strong enough for a TACL-level contribution. Do not exaggerate it.

## Stop-the-loop rules
1. Use `FREEZE_GATE_REPORT.md` as the canonical gate ledger. Other status files must be generated from it or state clearly that it is the single source of truth. Eliminate contradictory “FROZEN”, “PASS”, “BLOCKED”, and annotation-status claims.
2. Never mark an issue resolved because a report says it is resolved. Require an artifact, assertion, test, citation, or reproducible output that demonstrates the fix.
3. Keep the supplied ZIP immutable; work in a new versioned folder.
4. Do not repeatedly rewrite the same documents. Fix underlying code/data first, run it, then regenerate all summaries from the outputs once.
5. Do not tune methods, thresholds, labels, or hypotheses using the test labels. The existing N=163 test partition was inspected in earlier iterations; mark all results on it “exploratory / previously inspected”. It cannot be presented as a fresh confirmatory test.
6. Do not force a positive outcome. If the method fails, record the negative result and remove unsupported claims of improvement.
7. No invented human annotators, fabricated labels, guessed citations, or simulated results presented as real.
8. Do not ask the user questions unless actual external action is unavoidable. For this scope, continue without human annotation by removing causal claims. Clearly list any additional data/personnel needed for a future causal study.

## Required work, in order

### Gate 1 — Inventory and provenance
- Create a complete file inventory and hash the original archive.
- Identify active vs superseded/legacy artifacts. Move stale reports, figures, outputs, and manuscript drafts to `archive/superseded/` or clearly label them; do not delete the originals.
- Verify dataset source, exact files, licenses/usage terms, label distribution, and train/dev/test overlap.
- Keep all annotations marked synthetic/invalidated quarantined; ensure active analysis never reads them.

### Gate 2 — Fix the task definition
- Implement the fixed scope above consistently in every active protocol and report.
- State what the X-Fact labels represent and exactly how they are mapped to the verifier output space.
- Explicitly note that the current Hindi dev/test subset contains zero gold `SUPPORTED` examples. Do not imply general three-class validation performance from this subset.
- Report the observed two-class Macro-F1 on the non-empty gold classes as the primary descriptive F1. If three-class nominal Macro-F1 is retained, label it secondary and explain the absent class. Report per-class support, precision, recall, F1, confusion matrix, accuracy, and majority/constant baseline.
- Do not silently remap labels to make a result look better. Verify label IDs from the loaded model configuration and test the mapping with unit tests.
- If the current projected label mapping is insufficient for a claimed metric, label that metric a proxy/diagnostic and narrow the interpretation.

### Gate 3 — Threshold selection and baseline fairness
- Audit `protocol/analysis_plan.yaml`, the tuning script, and all threshold CSVs. Identify the documented threshold grid and whether it was pre-specified before looking at results.
- Current V4 tuning files only search tau values from 0.10 through 0.65. Include and explicitly compare the no-check operating point (zero original-evidence consultations) using the same development-only utility objective.
- The current objective is reported as `J = Macro_F1_3cl - 0.15 * Coverage`. At tau=0.65 the saved development score is 0.2023; the saved no-check score has been reported as 0.2104. Verify both by recomputation. If the no-check point wins, do not describe selective routing as the utility-optimal strategy. Report tau=0.65 only as the best threshold inside its declared grid if that is what it is.
- Do not claim pre-registration if the protocol was written after experiments. Record when the objective and grid were actually fixed, or call the analysis exploratory.
- Freeze the threshold from development data only. Never optimize or pick a threshold on the test set.
- Recompute all threshold tables and routing masks directly from canonical development predictions; assert every routed example follows `risk_score >= tau_star`.

### Gate 4 — Canonical inference and all results
- Verify the exact generated MarianMT output used as the verifier input. Never time a new translation and then verify an unrelated cached translation. The primary end-to-end timing must measure the exact path used for the prediction.
- Ensure truncation is token-based and use one consistent tokenizer/length policy. Log model IDs/revisions, package versions, device, seed, decoding settings, batch size, sequence lengths, and timing methodology.
- Run inference on dev and test from scratch if resources permit. If the raw test set has already been repeatedly inspected, results remain exploratory; no test-driven tuning is allowed.
- Recompute all baselines from the same canonical per-example table: translated-only, original-only, always-check, selective hard routing, any posterior-averaging variant, uncertainty-only, numeral-only, and random routing only where the baseline is meaningfully specified.
- For random routing, use at least 100 predeclared seeds and exact matched consultation count/coverage for each comparison. Report the distribution (mean, SD, percentile interval), not only the best seed.
- Include simple baselines: majority/constant-label predictor, no-check, and original-only. Compare methods at matched coverage as well as by each method’s natural operating point.
- Report per-instance predictions, probabilities, risk scores, trigger flags, gold mapped label, correctness, latency components, and source item ID.
- Compute confidence intervals and paired tests from the same canonical outputs. State all test definitions, number of resamples/permutations, seeds, and multiple-comparison correction. Do not mix p-values or metrics from older runs.
- Given the observed test metrics so far, selective-check has not convincingly improved over translated-only and performs worse than original-only/always-check. Preserve this conclusion unless a fresh, correctly specified run supports another result. A negative result is acceptable; manufactured success is not.

### Gate 5 — Literature and contribution reality check
- Verify every citation against a primary publisher, proceedings, or arXiv source. No placeholder IDs or fabricated bibliographic details.
- Compare the proposed observational contribution specifically with XFEVER / cross-lingual verification, multilingual translation-bias studies, and selective inference/routing literature.
- Remove “first”, “novel”, “causal”, and “state-of-the-art” claims unless evidence specifically supports them.
- Write a short internal contribution statement: what is actually new relative to nearest neighbors; what is only a replication or diagnostic; what is not supported.
- Provide a candid TACL suitability assessment. Do not promise acceptance. If the present study is too narrow or underpowered, say so and name the specific additional evidence that would be required; do not use endless speculative experiments to disguise this limitation.

### Gate 6 — Tests and clean-room reproducibility
- Create/review automated tests for label mapping, missing-class handling, threshold selection including the zero-check option, routing flags, metrics, confidence intervals, latency aggregation, randomized baseline count matching, and stale/synthetic annotation exclusion.
- Install dependencies from the provided environment file and run tests in the documented supported Python version. Record actual command, environment, stdout/stderr, and exit code. If a dependency cannot be installed, report it as a blocker—not a pass.
- Extract the candidate ZIP to a new path and run the documented reproduction command without relying on the creator’s absolute paths or undeclared cache files.
- Rebuild all figures and tables from the canonical output files.

### Gate 7 — One source of truth and packaging
Create these canonical files:
- `FREEZE_GATE_REPORT.md` — one authoritative PASS/BLOCKED table with evidence paths.
- `RESEARCH_STATUS.md` — generated from the gate report or an exact consistent summary.
- `protocol/FINAL_SCOPE_AND_CLAIMS.md` — task, labels, permitted claims, excluded claims, split status, limitations.
- `experiments/results_canonical/` — final predictions, metrics, threshold tables, statistics, latency, seeds, and generated figures.
- `experiments/results_canonical/RUN_MANIFEST.json` — command, timestamp, git/archive hash if available, input hashes, model IDs/revisions, dependencies, environment, seed, configs, output hashes.
- `reproducibility/REPRODUCE.md` — fresh-extraction instructions.
- `reproducibility/TEST_REPORT.md` — actual test command and results.
- `audit/ISSUE_LEDGER.csv` — each previous issue with evidence and a verifiable resolution or explicit blocker.
- `audit/SHA256SUMS.txt` — hashes of final files; document exclusions for the manifest itself.
- `TACL_READINESS_ASSESSMENT.md` — research readiness only, not a manuscript draft.

Remove contradictions from active documents. Keep superseded results only in a visibly quarantined archive. Do not create or edit a new manuscript in this task.

## Freeze decision criteria
The package may be marked `RESEARCH FROZEN — EXPLORATORY SCOPE` only if all of the following are true:
1. Scope is explicitly narrowed to prediction sensitivity/routing disagreement; no causal human-annotation claims remain.
2. Synthetic annotations are quarantined and are not used in active outputs.
3. Label mapping and absent-class behavior are tested and honestly disclosed.
4. Development threshold selection includes a no-check baseline and is recomputed from canonical predictions.
5. The exact translation used by the verifier is the one measured in the inference/timing pipeline.
6. All canonical metrics, tables, figures, and stats regenerate from per-example outputs.
7. Clean-room tests and reproduction succeed in the stated environment.
8. All status and gate documents agree exactly.
9. Test set is explicitly marked previously inspected/exploratory.
10. The final ZIP contains all necessary code, data provenance, permitted data, configs, outputs, logs, manifest, and instructions.

If any of these fails, label it `NOT FROZEN`, list only the remaining blocking items, and deliver the best package possible without another recursive round of invented fixes.

## Final output to the user
Provide only:
1. A concise summary of what was verified and actually changed.
2. The final freeze decision and each gate's status.
3. The honest research conclusion, including negative results.
4. Any true external blocker (e.g., human annotators) and why it is or is not required for the chosen scope.
5. A link to one final versioned ZIP.
6. A short statement on TACL suitability and required additional evidence.

Never claim the work is frozen merely because this prompt says to freeze it. Evidence decides the outcome.
