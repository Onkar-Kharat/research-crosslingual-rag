# ANTIGRAVITY MASTER PROMPT: FINALIZE RESEARCH VALUES, BUILD A REAL HUMAN-ANNOTATION WORKFLOW, AND FREEZE THE RESEARCH PACKAGE

## Mission

Work from the supplied project archive:

`CROSS_LINGUAL_EVIDENCE_VERIFICATION_RESEARCH_V5_FROZEN_EXPLORATORY.zip`

The goal is to finish the remaining research validation and packaging work in one controlled pass. Do **not** start or rewrite the manuscript. Do not start another open-ended research redesign cycle. Produce one reproducible, internally consistent research package and make an evidence-based freeze decision.

This prompt supersedes older project prompts where they conflict with the rules below. Read the existing audit reports, freeze report, annotation protocol, canonical data, scripts, test results, and manifests, but verify claims against actual files and reproducible outputs rather than trusting status labels.

## Non-negotiable integrity rules

1. **Never fabricate human annotation.** Do not use an LLM, Python script, hard-coded dictionary, heuristic, model prediction, or synthetic example as a human response. Automated checks may validate file format, calculate statistics, or detect missing answers; only actual human annotators may provide human judgments.
2. **An annotation interface helps real people annotate; it does not annotate for them.** The interface may randomize and blind items, validate inputs, save files, and calculate agreement after real submissions arrive. It must not suggest a label, generate rationales, infer answers, or auto-fill judgments.
3. **Do not change test-set results to improve a score.** The existing 163-item test set has already been inspected in previous iterations. Treat it as exploratory/descriptive. Threshold selection and all design choices must use development data only. Never claim confirmatory generalization from the inspected test set.
4. **One source of truth.** Active tables, plots, summaries, status reports, and manifests must be generated from the canonical per-instance predictions and canonical run manifest. Older results must be clearly archived as superseded and must not feed active outputs.
5. **Do not overclaim.** Current scope is an observational study of cross-lingual verifier prediction sensitivity and routing disagreement under Hindi-to-English translation shift. The tested code evaluates pre-retrieved evidence with a verifier; it is not a complete end-to-end RAG system. Unless authentic human annotations validate semantic distortions, do not make causal claims that translation corruption caused particular errors.
6. **Negative results remain results.** Do not claim Selective-Check improves performance if the canonical results do not support that. Report the baseline comparisons and the fact that no-check achieved a higher development utility under the stated objective if it remains true after independent recalculation.
7. **No false freeze.** A status file must reflect evidence. If an external human action remains pending, distinguish “COMPUTATIONAL RESULTS FROZEN — EXPLORATORY” from “HUMAN-VALIDATED ERROR ATTRIBUTION COMPLETE.” Never silently collapse these into one claim.
8. **Preserve the original.** Extract to a new working directory and keep the supplied ZIP unchanged. Record the SHA-256 of the input ZIP and create a versioned output archive.

---

## Phase 0 — Intake, backup, and inventory

1. Record the input ZIP SHA-256 and inventory its files.
2. Extract to a new, clean working directory. Do not edit the original archive or overwrite previous runs.
3. Read at least these active files and verify their claims: `FREEZE_GATE_REPORT.md`, `RESEARCH_STATUS.md`, `STATUS.md`, `README_RESEARCH_FREEZE.md`, `annotation/HUMAN_ANNOTATION_REPORT.md`, `annotation/ANNOTATION_PROTOCOL.md`, `annotation/ANNOTATION_GUIDE.md`, `experiments/results_canonical/`, `experiments/results_corrected/`, `scripts/`, `tests/`, `reports/`, `literature/`, `TACL_READINESS_ASSESSMENT.md`, and the run/checksum manifests.
4. Create `FINAL_PASS/INPUT_INVENTORY.md` and `FINAL_PASS/INITIAL_DISCREPANCIES.csv`. Include file path, statement/value, evidence path, and status (`verified`, `contradictory`, `stale`, `not reproducible`, or `requires human input`).
5. Check the earlier annotation contradiction explicitly. The archive must not retain any active statement implying that humans completed annotation unless real, independently supplied submission files prove it. Keep synthetic outputs only in the quarantined audit folder and visibly label them invalid.

## Phase 1 — Lock the research scope and claims

Create `protocol/FINAL_SCOPE_AND_CLAIMS.md` (or update the existing canonical scope file) with the following fixed scope:

**Study scope:** An observational study of model prediction sensitivity and routing behavior when evidence is represented in original Hindi versus machine-translated English.

**What is evaluated:** A multilingual NLI verifier on pre-retrieved evidence snippets under paired language conditions, using the current documented model and translation pipeline.

**What is not evaluated:** A full retriever-generator RAG stack; broad multilingual generalization; causal attribution to translation-fidelity corruption without authentic human annotation; or confirmatory generalization from the previously inspected test set.

**Primary descriptive outcomes:** Paired prediction agreement/disagreement and label-flip patterns across the original-Hindi and translated-English conditions. Define and implement these precisely in one metrics specification. Report counts, rates, and appropriate confidence intervals.

**Secondary outcomes:** Accuracy/F1 against the currently mapped X-Fact labels, latency, consultation coverage, and route comparisons. Clearly identify these label-based results as proxy/exploratory because the Hindi partition lacks a gold `SUPPORTED` class and X-Fact veracity ratings are not the same thing as native sentence-level NLI labels.

Remove or revise phrases including `caused by translation`, `causal translation error`, `human-confirmed`, `first`, `state of the art`, and `end-to-end RAG` wherever unsupported. Keep relevant limitations explicit. Do not erase the fact that human validation was not completed.

Do not change this scope during the run merely to make the results look stronger. If the scope cannot be represented honestly, document the exact reason and stop short of freeze.

## Phase 2 — Build a practical, genuinely human annotation workflow

The purpose is to let qualified Hindi–English bilingual people annotate independently with minimum friction. The user may not personally annotate the sample. Build a reusable workflow that can be handed to real external annotators and later ingested without manual data cleaning.

### 2.1 Deliverables for the annotation system

Create the following or equivalent well-documented paths:

- `annotation_tool/README.md`
- `annotation_tool/ANNOTATOR_INSTRUCTIONS.md`
- `annotation_tool/app/` (the annotation interface and any assets)
- `annotation_tool/scripts/prepare_blinded_packets.py`
- `annotation_tool/scripts/validate_submissions.py`
- `annotation_tool/scripts/analyze_agreement.py`
- `annotation_tool/templates/` (empty submission schema and completion checklist)
- `annotation_tool/packets/` (blinded packet ZIPs generated from actual sampled rows; no responses prefilled)
- `annotation_tool/submissions/README.md` (must be empty of fake human answers)
- `annotation_tool/analysis/` for analysis outputs, populated only after genuine submissions arrive

Choose the simplest maintainable implementation compatible with Windows 10/11 and the project's local Python environment. Prefer a self-contained offline browser interface or a small local web app with no paid APIs, telemetry, external service dependency, or account requirement. If a web app needs a server, document exactly how the annotator launches it locally. Do not expose an app publicly or publish participant data without explicit authorization.

### 2.2 Annotation task and label schema

The annotator's task is **translation fidelity**, not deciding whether the factual claim is true and not guessing the model's label. The interface shows the claim for context, original Hindi evidence, and machine-translated English evidence. It must hide:

- gold/projected label;
- translated and original verifier predictions;
- model confidence or risk score;
- operational error category or sampling stratum;
- results of the other annotator;
- any “expected answer” or model-generated rationale.

For each item, collect:

1. `fidelity_label` — exactly one of:
   - `PRESERVED`: claim-relevant factual semantics are preserved;
   - `ALTERED`: a claim-relevant semantic detail has been changed, omitted, added, inverted, or garbled in translation;
   - `AMBIGUOUS_SOURCE`: the Hindi source itself is too incomplete/ambiguous to make a reliable fidelity judgment;
   - `UNABLE_TO_DECIDE`: annotator cannot decide, e.g., due to language/domain limitations.
2. `distortion_types` — zero or more of `NUM_DATE`, `NEGATION`, `ENTITY`, `OMISSION`, `HALLUCINATION`, `QUALIFIER`, `TIME`, `OTHER`, or `NONE`. Require at least one substantive type for `ALTERED`; require `NONE` for `PRESERVED`; explain these rules in the guide.
3. `rationale` — required for `ALTERED`, `AMBIGUOUS_SOURCE`, and `UNABLE_TO_DECIDE`; short free text pointing to the semantic difference, not a truth judgment.
4. Optional `confidence` (`HIGH`, `MEDIUM`, `LOW`) for descriptive uncertainty only. Do not use confidence to overwrite the fidelity label.
5. `annotator_code` — pseudonymous code such as `A1` / `A2`; do not request names or sensitive personal information.
6. `opaque_item_id`, `protocol_version`, `packet_version`, `submission_timestamp_utc`, and `interface_version` for auditability.

The UI must distinguish a translation that is awkward but semantically faithful from one that changes claim-relevant meaning. Update the examples in the guide so examples are clearly illustrative, do not make the model's expected label apparent, and do not leak any sampled item's model prediction.

### 2.3 Sampling, blinding, and packet generation

1. Use the existing planned sample only if its provenance and sampling code can be verified. Otherwise regenerate the sample deterministically from the canonical dataset and record the seed, item IDs, strata, inclusion rules, and exclusions.
2. Existing sampling strata may be operational translation-flip cases, both-language-errors cases, and a control stratum. If used, strata are for sampling/analysis only and must be hidden from annotators.
3. Make two independent packets, one for each real annotator, using different randomized item orders and opaque random identifiers. Both annotators must receive the same underlying items so paired agreement can be calculated, but they must not see each other's answers.
4. Keep a mapping from opaque item IDs to source IDs and sampling strata in a separate analysis-only key file that is never included in annotator packets.
5. No prefilled labels, rationales, example responses for sampled items, or annotator-specific hints. Automated script may verify that packets contain no response fields with substantive values.
6. Create a short invitation/handoff note describing qualifications (demonstrable Hindi and English proficiency), expected effort based on actual pilot time, confidentiality, independence, and return instructions. Do not invent a promise about pay or compensation. The user must arrange actual annotators and any necessary consent/payment.
7. Create a small **interface QA fixture** only if needed for testing, using obviously synthetic, clearly marked non-study examples stored outside the real packets. Never include the fixture in analysis.

### 2.4 Submission validation

The validator must check, without altering answers:

- expected number of unique opaque item IDs;
- no missing or duplicate items;
- valid enum values;
- `ALTERED` has at least one valid distortion type and a rationale;
- `PRESERVED` has `NONE` or an explicitly documented empty type field, consistently;
- all answers contain annotator code, protocol version, and packet version;
- each annotator file is from a distinct declared annotator code;
- each annotator independently completed the packet before any adjudication;
- no hidden model fields or internal stratum fields were added to returned files.

If a file fails validation, create a clear error report; never silently repair labels or synthesize missing responses.

### 2.5 Agreement, adjudication, and reporting

When and only when two authentic annotation files have been returned:

- align items by opaque item ID using the analysis-only key;
- report completion counts and exclusions;
- calculate raw agreement and Cohen's kappa for the pre-specified fidelity-label comparison, with a confidence interval or clear small-sample caveat;
- report label prevalence and the number of `AMBIGUOUS_SOURCE` / `UNABLE_TO_DECIDE` cases; kappa can be unstable with low prevalence, so do not report it alone;
- report agreement on distortion types separately and clearly identify the multi-label nature of that analysis;
- produce a disagreement queue for real adjudication by a qualified third reviewer or a documented adjudication procedure. Do not auto-adjudicate disagreements;
- estimate the proportion of operationally translation-sensitive cases labeled `ALTERED`, with a confidence interval, using the sampling design correctly. If the sample is stratified, do not report the raw sample fraction as a population prevalence without appropriate weighting;
- publish a report that says who/what provided labels only to the level consented/approved by the annotators. Do not include names unless explicitly authorized.

Do not set or change a pass threshold after seeing annotation results. Before distributing the packets, record the intended interpretation and any decision rule in `annotation/ANNOTATION_ANALYSIS_PLAN.md`. If a threshold such as “70% altered” is retained, give a defensible pre-analysis rationale and call it a project-specific criterion, not a universal scientific standard. Prefer reporting estimates and uncertainty over a simplistic pass/fail threshold.

### 2.6 Do not block unrelated computation on human recruitment

The tool must be built and tested now, but no synthetic annotations may be inserted while waiting for real annotators. The project may complete a **computational exploratory freeze** without human annotation only if it retains the fixed observational scope and makes no human-validated or causal error-attribution claims. The status must then say `HUMAN ANNOTATION: PENDING / NOT PERFORMED`. A stronger human-validated claim remains blocked until real submissions and any required adjudication are complete.

## Phase 3 — Finalize canonical experiment values

1. Identify the single canonical inference script, config, and output directory. Record the command used, software/model versions, seeds, hardware, runtime, and input file hashes.
2. Verify direct coupling between translation generation and verifier input: the exact newly generated translation used for inference must be the one whose latency is measured. If inference uses cached translations, explicitly treat that as a separate cached-input experiment and do not label it end-to-end translation latency.
3. Confirm genuine token-based truncation and document the truncation/tokenizer policy.
4. Ensure no dev/test contamination: threshold tuning, routing rule choices, calibration, feature selection and model selection use development data only. Treat the existing test set as previously inspected/exploratory. Do not tune against test results.
5. Recompute all metrics from canonical per-example predictions. Include the following where applicable:
   - paired prediction agreement and label-flip counts/rates, with uncertainty intervals;
   - confusion matrices and per-class support;
   - accuracy, macro-F1 over the actually observed classes, nominal three-class macro-F1 only as a clearly labeled secondary/proxy measure, and a majority-class baseline;
   - inference coverage and consultation rate with explicit denominator definitions;
   - end-to-end latency measured on the actual inference path, with repeated measurements or a documented measurement policy;
   - paired significance tests, effect sizes, confidence intervals and multiple-comparison correction when comparisons are numerous;
   - random routing control with repeated seeds and matched consultation counts, if this baseline remains in the protocol.
6. Explicitly include the no-check point in threshold/objective tables. Under the stated objective `J = MacroF1 - lambda * Coverage`, if no-check has a higher development objective than every cascade point, report that fact. Do not describe the cascade threshold as the global optimum; it can only be reported as the best conditional cascade threshold if the calculation supports it.
7. Explain the majority-class problem: the current dataset projection contains no gold `SUPPORTED` examples in the relevant split. Keep label-based scores exploratory/proxy metrics and do not claim validated three-class evidence verification.
8. Do not change the scope or metrics after observing whether the result is positive. If the final results are negative, make that explicit in the conclusions of the research report, not as a manuscript draft.
9. Generate one canonical table/JSON of results and make every active report and figure read from it. Do not hand-copy numbers into reports.
10. If any reported value cannot be recreated from available artifacts, remove it from active outputs or mark it unresolved. Do not substitute estimates or values from legacy outputs.

## Phase 4 — Literature and provenance sanity check

1. Validate every cited work in the literature audit against a real primary source (ACL Anthology, arXiv, publisher proceedings, or official project page).
2. Remove placeholders, non-existent references, and statements marked verified without evidence.
3. Keep claims about novelty narrow and comparative. No “first” claim unless the audit supports it and the wording is precisely bounded.
4. Record dataset/license provenance, model checkpoints/versions, translation model version, all preprocessing choices, and any redistribution restrictions.
5. Do not write or update the full TACL manuscript. Only update research protocol, experiment results, and readiness documents needed to freeze the research.

## Phase 5 — Reproducibility and final source-of-truth cleanup

1. Reconcile `FREEZE_GATE_REPORT.md`, `RESEARCH_STATUS.md`, `STATUS.md`, `README.md`, `README_RESEARCH_FREEZE.md`, `REVIEW_ME_FIRST.md`, `TACL_READINESS_ASSESSMENT.md`, annotation status, and test report. Every active status must agree.
2. Archive older reports, figures, metrics, and manuscript artifacts into `archive/superseded/` or clearly label them `SUPERSEDED — DO NOT USE`. Preserve forensic audit history but ensure it cannot silently feed current outputs.
3. Install the documented requirements in a fresh Windows-compatible environment (and optionally a clean Linux test environment if readily available). Run tests from a clean extraction. Capture the actual command, environment, test count, pass/fail counts, and any failures. A report of past tests is not a substitute for executing them.
4. Add tests for the annotation tool: randomized/blinded packet generation, empty response fields, required field validation, duplicate/missing item checks, schema compatibility, no prediction leakage, two-annotator alignment, and agreement calculations on a clearly artificial QA fixture only.
5. Build the checksum manifest **after** every file has reached its final version; verify it against the exact files inside the delivered ZIP. Avoid self-referential checksum rules (do not claim the archive checksum is inside itself unless designed appropriately).
6. Build one versioned final ZIP in a new output path. Include code, permitted data or retrieval instructions, license/provenance notes, canonical per-instance predictions, canonical results, configs, logs, tests, annotation app and empty handoff packets, analysis scripts, and the decision report. Do not include real annotator personal information or fake annotations.
7. Re-extract the final ZIP into a separate scratch directory and rerun the documented lightweight validation/test command. Verify the checksums after extraction.

## Phase 6 — Freeze decision

Produce `FINAL_PASS/FINAL_RESEARCH_FREEZE_DECISION.md` with one of these exact statuses:

### Status A: `COMPUTATIONAL RESULTS FROZEN — EXPLORATORY; HUMAN ANNOTATION PENDING`
Use this only if the computational results are reproducible, status/report contradictions are resolved, scope and limitations are accurate, active outputs are canonical, and the fresh-extraction test/evidence checks pass. This status does **not** claim human validation.

### Status B: `HUMAN-VALIDATED DIAGNOSTIC STUDY FROZEN`
Use this only if authentic independent human submissions are received, validated, analyzed under the pre-specified plan, any required adjudication is real and documented, and all computational and packaging gates pass.

### Status C: `NOT FROZEN`
Use this if essential data, inference, annotation integrity, metrics, provenance, or reproducibility remains unresolved. List exact blockers and evidence paths. Do not use a “frozen” filename to imply completion.

The final decision report must include:
- fixed scope and out-of-scope claims;
- canonical numerical values and the file/script that produced each;
- all deviations from earlier versions;
- annotation status and whether the app has been tested with only QA fixtures or real annotators;
- test commands and actual output summary;
- checksum verification result;
- known limitations and any external action still required;
- exact name and SHA-256 of the delivered ZIP.

## Final deliverables

Create a new versioned ZIP named to reflect its truthful status, e.g.:

- `CROSS_LINGUAL_EVIDENCE_VERIFICATION_RESEARCH_COMPUTATIONAL_FROZEN_EXPLORATORY_v6.zip`, or
- `CROSS_LINGUAL_EVIDENCE_VERIFICATION_RESEARCH_NOT_FROZEN_v6.zip`.

Also produce:
- `FINAL_PASS/FINAL_RESEARCH_FREEZE_DECISION.md`
- `FINAL_PASS/CANONICAL_VALUES_TABLE.csv` (each value plus source script/file and definition)
- `FINAL_PASS/REMAINING_ACTIONS.md` (only actual external or unresolved tasks)
- `annotation_tool/` with the real-annotator workflow and empty packet templates
- `FINAL_PASS/SHA256SUMS.txt`
- `FINAL_PASS/REPRODUCE_FROM_CLEAN_EXTRACTION.md`

Do not create the manuscript in this task. Do not declare success before the final ZIP is created, re-extracted, validated, and checked.

---

## Launch message to use after setting this file as the active Antigravity instruction

Start the one-pass finalization workflow now using `CROSS_LINGUAL_EVIDENCE_VERIFICATION_RESEARCH_V5_FROZEN_EXPLORATORY.zip`.

First inventory and independently verify the existing evidence. Build the real-human annotation interface and two blinded independent annotator packets, but do not invent or prefill any human labels. Finish all computational finalization, canonical metrics, threshold reporting, literature/provenance checks, active-document reconciliation, tests, and packaging that can be done without new human input.

Keep the study scope fixed as observational prediction sensitivity under Hindi-to-English translation shift. Clearly distinguish the computational exploratory freeze from a human-validated diagnostic freeze. Because I cannot personally complete all annotation work, make the annotator workflow easy to hand to qualified bilingual annotators and provide a one-page handoff note. Do not claim human validation until real completed files are returned.

Do not write the manuscript. Deliver one versioned ZIP after clean-extraction verification, plus the final freeze-decision report and canonical value table. If all computational gates pass but human annotation is pending, use the exact status `COMPUTATIONAL RESULTS FROZEN — EXPLORATORY; HUMAN ANNOTATION PENDING`. If any computational gate fails, use `NOT FROZEN` and identify only specific unresolved blockers. Do not start another loop of report rewrites or method changes to chase better test results.
